import React, { Component, Fragment } from 'react';
import DashboardIcon from '@atlaskit/icon/glyph/dashboard';
import BacklogIcon from '@atlaskit/icon/glyph/backlog';
import IssuesIcon from '@atlaskit/icon/glyph/issue';
import ReportsIcon from '@atlaskit/icon/glyph/graph-line';
import { gridSize as gridSizeFn } from '@atlaskit/theme';

import {
  GlobalNav,
  LayoutManager,
  NavigationProvider,
  MenuSection,
  SkeletonContainerView,
  light,
  dark,
  settings,
  ContainerHeader,
  HeaderSection,
  ItemAvatar,
  Item,
  ThemeProvider,
} from '@atlaskit/navigation-next';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Reset, Theme } from '@atlaskit/theme';
import Button from '@atlaskit/button';

// CSS

import "./App.css";

// Glyphs

import { faStore, faUser, faDice, faTag, faWallet, faCog } from '@fortawesome/free-solid-svg-icons'
import { faEthereum } from '@fortawesome/free-brands-svg-icons'
// Images

import ESCA from "./images/ESCA.png"
import DAO from "./images/DAO.png"

// Constants

const userIcon = () => <FontAwesomeIcon icon={faUser} size='1x'/>
const storeIcon = () => <FontAwesomeIcon color="#0cff6f" icon={faStore} size='1x'/>
const cogIcon = () => <FontAwesomeIcon color="#0cff6f" icon={faCog} size='1x'/>
const walletIcon = () => <FontAwesomeIcon color="#0cff6f" icon={faWallet} size='1x'/>
const ethIcon = () => <FontAwesomeIcon icon={faEthereum} size='1x'/>
const diceIcon = () => <FontAwesomeIcon icon={faDice} size='1x'/>
const diceIconG = () => <FontAwesomeIcon color="#0cff6f" icon={faDice} size='1x'/>

const gridSize = gridSizeFn();
const themeModes = { light, dark, settings };

const GlobalNavigation = () => (
  <GlobalNav primaryItems={[
    { key: 'market', icon: storeIcon, label: 'Market' },
    { key: 'wager', icon: diceIconG, label: 'Wager' },
    { key: 'wallet', icon: walletIcon, label: 'wallet' },
    { key: 'settings', icon: cogIcon, label: 'settings' },
  ]} secondaryItems={[]} />
);

export default class Example extends Component<{}, State> {
  state = {
    themeMode: 'dark',
    shouldShowContainer: true,
    shouldRenderSkeleton: false,
  };

  renderNavigation = () => {
    return (
      <Fragment>
      <ContainerHeader/>
        <MenuSection>
          {({ className }) => (
            <div className={className}>
              <Item before={diceIcon} text={this.state.bet} subText="BET" />
              <Item before={ethIcon} text={this.state.eth} subText="ETH" />
            </div>
          )}
        </MenuSection>
      </Fragment>
    );
  };

  renderSkeleton = () => {
    return <SkeletonContainerView />;
  };

  handleShowContainerChange = () => {
    this.setState({ shouldShowContainer: !this.state.shouldShowContainer });
  };

  render() {
    const { shouldRenderSkeleton, shouldShowContainer, themeMode } = this.state;
    const renderer = shouldRenderSkeleton
      ? this.renderSkeleton
      : this.renderNavigation;
    return (
      <NavigationProvider>
        <ThemeProvider
          theme={theme => ({
            ...theme,
            mode: themeModes[themeMode],
          })}
        >
          <LayoutManager
            globalNavigation={GlobalNavigation}
            productNavigation={renderer}
          >

          <Theme values={() => ({ backgroundColor: '#6f0cff', textColor: '#ffffff' })}>
          <Reset style={{ padding: 350 }}>

          <div className="headerESCA">
            <img className="logoDAO" src={DAO}/>
            <img className="logoESCA" src={ESCA}/>
          </div>

          <div className="gamblingUI">

          </div>

          <div className="transactionalUI">
          </div>

          </Reset>
          </Theme>
          </LayoutManager>
        </ThemeProvider>
      </NavigationProvider>
    );
  }
}
